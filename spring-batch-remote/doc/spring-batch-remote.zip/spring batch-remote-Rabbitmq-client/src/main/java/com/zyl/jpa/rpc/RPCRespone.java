package com.zyl.jpa.rpc;

import java.io.Serializable;

public class RPCRespone implements Serializable
{
	private static final long serialVersionUID = -2525276470575045949L;
}
