package com.zyl.jpa.rpc;

public interface RPCservice {

	public String getRPC(String request);
}
