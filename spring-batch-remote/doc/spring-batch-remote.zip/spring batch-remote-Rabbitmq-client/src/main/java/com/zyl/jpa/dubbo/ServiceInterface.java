package com.zyl.jpa.dubbo;

public interface ServiceInterface {

	public String getDubboRPC(String a);
	
}
