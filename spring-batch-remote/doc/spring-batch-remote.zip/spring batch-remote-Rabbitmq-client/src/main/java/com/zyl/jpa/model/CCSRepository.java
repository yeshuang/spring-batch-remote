package com.zyl.jpa.model;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zyl.jpa.domain.CcsAcctNbr;

public interface CCSRepository extends JpaRepository<CcsAcctNbr,Long>{

}
