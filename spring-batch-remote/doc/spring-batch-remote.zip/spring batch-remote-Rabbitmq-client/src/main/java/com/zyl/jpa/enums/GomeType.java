package com.zyl.jpa.enums;

public enum GomeType {
	gome01,gome02,gome03
}
