package com.zyl.jpa.rpc;

public class RPCserviceImpl implements RPCservice {

	public String getRPC(String request) {
		return "respone" + request;
	}

}
