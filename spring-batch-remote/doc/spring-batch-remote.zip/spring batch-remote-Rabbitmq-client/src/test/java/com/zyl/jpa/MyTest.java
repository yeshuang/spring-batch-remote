package com.zyl.jpa;

public class MyTest {

	public void syso(){
		System.out.println(123);
	}
}
